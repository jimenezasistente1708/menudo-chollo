(() => {
'use strict';

/* Todos los datos viven en data/productos.json. Este archivo no se toca a diario. */
const RUTA_DATOS = 'data/productos.json';

const $ = (s) => document.querySelector(s);
const eur = new Intl.NumberFormat('es-ES', { style: 'currency', currency: 'EUR' });
const fechaCorta = new Intl.DateTimeFormat('es-ES', { day: '2-digit', month: '2-digit' });
const norm = (t) => String(t).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');

/* Dominios permitidos por tienda: evita enlaces mal pegados. */
const DOMINIOS = {
  amazon:     [/(^|\.)amazon\.(es|com)$/, /^amzn\.to$/],
  aliexpress: [/(^|\.)aliexpress\.(com|es)$/],
  ebay:       [/(^|\.)ebay\.(es|com)$/, /^ebay\.us$/],
  awin:       [/(^|\.)awin1\.com$/]
};

let datos = null;
const estado = { cat: 'todas', tienda: 'todas', q: '', orden: 'recientes' };

function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
}

/* ---------- Utilidades de datos ---------- */
function diasDesde(iso) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(iso || '')) return null;
  const t = Date.parse(iso + 'T00:00:00');
  return Number.isNaN(t) ? null : Math.floor((Date.now() - t) / 86400000);
}

function urlValida(p) {
  try {
    const u = new URL(p.url);
    if (u.protocol !== 'https:') return false;
    const pat = DOMINIOS[p.tienda];
    return !pat || pat.some((r) => r.test(u.hostname));
  } catch (e) {
    return false;
  }
}

/* Amazon: añade tu ID de afiliado. AliExpress y eBay: pega en "url" el enlace
   de afiliado que te da su panel; aquí no se modifica. */
function enlace(p) {
  if (!urlValida(p)) return '#';
  const u = new URL(p.url);
  if (p.tienda === 'amazon' && datos.config.amazonTag) u.searchParams.set('tag', datos.config.amazonTag);
  return u.toString();
}

const puedePrecio = (p) => p.tienda !== 'amazon' || datos.config.amazonPreciosPermitidos === true;

function porcentaje(p) {
  if (!(p.precio > 0) || !(p.precioAnterior > p.precio)) return 0;
  return Math.round((1 - p.precio / p.precioAnterior) * 100);
}

function publicables() {
  const demo = datos.config.modoDemo === true;
  const caduca = Number(datos.config.caducidadDias) || 7;
  return datos.productos.filter((p) => {
    const t = datos.tiendas[p.tienda];
    if (!t) return false;
    if (demo) return true;
    if (t.estado !== 'activo') return false;
    if (!urlValida(p)) return false;
    const d = diasDesde(p.actualizado);
    return d !== null && d <= caduca; // los chollos viejos desaparecen solos
  });
}

/* ---------- Tarjeta ---------- */
function crearImagen(p, thumb) {
  const permitida = p.img && (p.tienda !== 'amazon' || datos.config.amazonImagenesPermitidas === true);
  const cat = datos.categorias.find((c) => c.id === p.categoria);
  const icono = () => {
    const s = el('span', null, cat ? cat.icono : '🛍️');
    s.setAttribute('aria-hidden', 'true');
    return s;
  };
  if (!permitida || !/^https:\/\//.test(p.img)) { thumb.appendChild(icono()); return; }
  const img = document.createElement('img');
  img.src = p.img; img.alt = p.titulo; img.loading = 'lazy'; img.width = 400; img.height = 300;
  img.referrerPolicy = 'no-referrer';
  img.addEventListener('error', () => { img.replaceWith(icono()); });
  thumb.appendChild(img);
}

function crearTarjeta(p) {
  const nombreTienda = datos.tiendas[p.tienda].nombre;
  const li = el('li');
  const card = el('article', 'card');

  const thumb = el('div', 'thumb');
  crearImagen(p, thumb);
  thumb.appendChild(el('span', 'store store--' + p.tienda, nombreTienda));
  const pct = puedePrecio(p) ? porcentaje(p) : 0;
  if (pct > 0) thumb.appendChild(el('span', 'save', '-' + pct + '%'));
  if (datos.config.modoDemo) thumb.appendChild(el('span', 'ribbon', 'Ejemplo'));

  const body = el('div', 'card__body');
  body.appendChild(el('h3', 'card__title', p.titulo));

  const precio = el('div', 'price');
  if (puedePrecio(p) && p.precio > 0) {
    precio.appendChild(el('span', 'price__now', eur.format(p.precio)));
    if (p.precioAnterior > p.precio) precio.appendChild(el('s', 'price__old', eur.format(p.precioAnterior)));
  } else {
    precio.appendChild(el('span', 'price__na', 'Ver precio en ' + nombreTienda));
  }
  body.appendChild(precio);

  const envioTxt = p.envio === 'gratis' ? 'Envío gratis' : p.envio === 'pago' ? 'Envío de pago' : 'Envío: mira la tienda';
  const envioCls = p.envio === 'gratis' ? 'ship--gratis' : p.envio === 'pago' ? 'ship--pago' : 'ship--nd';
  body.appendChild(el('span', 'ship ' + envioCls, envioTxt));

  if (p.actualizado && diasDesde(p.actualizado) !== null) {
    body.appendChild(el('span', 'upd', 'Comprobado el ' + fechaCorta.format(new Date(p.actualizado + 'T00:00:00'))));
  }

  const a = el('a', 'cta', 'Ver oferta en ' + nombreTienda);
  const href = enlace(p);
  a.href = href;
  if (href === '#') a.setAttribute('aria-disabled', 'true');
  else { a.target = '_blank'; a.rel = 'sponsored nofollow noopener noreferrer'; }
  body.appendChild(a);

  card.appendChild(thumb);
  card.appendChild(body);
  li.appendChild(card);
  return li;
}

/* ---------- Filtros y pintado ---------- */
function filtrar() {
  const q = norm(estado.q.trim());
  const lista = publicables().filter((p) =>
    (estado.cat === 'todas' || p.categoria === estado.cat) &&
    (estado.tienda === 'todas' || p.tienda === estado.tienda) &&
    (!q || norm(p.titulo).includes(q))
  );
  if (estado.orden === 'ahorro') {
    lista.sort((a, b) => (puedePrecio(b) ? porcentaje(b) : 0) - (puedePrecio(a) ? porcentaje(a) : 0));
  } else {
    lista.sort((a, b) => String(b.actualizado || '').localeCompare(String(a.actualizado || '')) || b.id - a.id);
  }
  return lista;
}

function pintarCategorias() {
  const base = publicables();
  const ul = $('#cats');
  ul.textContent = '';
  [{ id: 'todas', nombre: 'Todas las ofertas', icono: '🔥' }].concat(datos.categorias).forEach((c) => {
    const n = c.id === 'todas' ? base.length : base.filter((p) => p.categoria === c.id).length;
    const li = el('li');
    const b = el('button');
    b.type = 'button';
    b.setAttribute('aria-current', String(estado.cat === c.id));
    const ico = el('span', 'ico', c.icono); ico.setAttribute('aria-hidden', 'true');
    b.appendChild(ico);
    b.appendChild(el('span', null, c.nombre));
    b.appendChild(el('span', 'n', String(n)));
    b.addEventListener('click', () => { estado.cat = c.id; pintar(); });
    li.appendChild(b);
    ul.appendChild(li);
  });
}

function pintarTiendas() {
  const cont = $('#tiendas');
  cont.textContent = '';
  const usadas = Array.from(new Set(publicables().map((p) => p.tienda)));
  if (usadas.length < 2) return;
  ['todas'].concat(usadas).forEach((t) => {
    const b = el('button', 'chip', t === 'todas' ? 'Todas las tiendas' : datos.tiendas[t].nombre);
    b.type = 'button';
    b.setAttribute('aria-pressed', String(estado.tienda === t));
    b.addEventListener('click', () => { estado.tienda = t; pintar(); });
    cont.appendChild(b);
  });
}

function pintar() {
  pintarCategorias();
  pintarTiendas();
  const lista = filtrar();
  const grid = $('#grid');
  grid.textContent = '';
  lista.forEach((p) => grid.appendChild(crearTarjeta(p)));
  $('#vacio').hidden = lista.length > 0;
  $('#contador').textContent = lista.length === 1 ? '1 chollo' : lista.length + ' chollos';
}

function configurarWhatsApp() {
  const url = datos.config.whatsappUrl || '';
  const ok = /^https:\/\/(chat\.whatsapp\.com|whatsapp\.com\/channel)\//.test(url);
  document.querySelectorAll('[data-wa]').forEach((a) => {
    if (ok) { a.href = url; a.target = '_blank'; a.rel = 'noopener noreferrer'; }
  });
  if (!ok) $('#avisos-texto').textContent = 'Estamos preparando nuestro canal de WhatsApp. Muy pronto podrás unirte desde aquí.';
}

/* ---------- Arranque ---------- */
async function iniciar() {
  try {
    const r = await fetch(RUTA_DATOS, { cache: 'no-cache' });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    datos = await r.json();
  } catch (e) {
    $('#error').hidden = false;
    $('#contador').textContent = '';
    return;
  }
  $('#banner-demo').hidden = datos.config.modoDemo !== true;
  configurarWhatsApp();

  $('#form-buscar').addEventListener('submit', (e) => {
    e.preventDefault();
    estado.q = $('#q').value;
    pintar();
    $('#contenido').scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
  $('#q').addEventListener('input', (e) => { estado.q = e.target.value; pintar(); });
  $('#orden').addEventListener('change', (e) => { estado.orden = e.target.value; pintar(); });
  pintar();
}

iniciar();
})();
