#!/usr/bin/env python3
"""Revisa data/productos.json y las páginas legales antes de publicar.
Uso:  python3 herramientas/validar.py
Sale con código 1 si hay errores (así se puede usar en automatizaciones)."""
import json, re, sys, datetime
from pathlib import Path
from urllib.parse import urlparse

RAIZ = Path(__file__).resolve().parent.parent
DOMINIOS = {
    "amazon":     [r"(^|\.)amazon\.(es|com)$", r"^amzn\.to$"],
    "aliexpress": [r"(^|\.)aliexpress\.(com|es)$"],
    "ebay":       [r"(^|\.)ebay\.(es|com)$", r"^ebay\.us$"],
    "awin":       [r"(^|\.)awin1\.com$"],
}
errores, avisos = [], []

def err(m): errores.append(m)
def aviso(m): avisos.append(m)

try:
    datos = json.loads((RAIZ / "data" / "productos.json").read_text(encoding="utf-8"))
except Exception as e:
    print("ERROR: no se puede leer data/productos.json:", e)
    sys.exit(1)

cfg = datos.get("config", {})
demo = cfg.get("modoDemo") is True
tiendas = datos.get("tiendas", {})
cats = {c["id"] for c in datos.get("categorias", [])}
caduca = int(cfg.get("caducidadDias") or 7)
hoy = datetime.date.today()

if demo:
    aviso("modoDemo está en true: la web mostrará productos de ejemplo.")
if not cfg.get("whatsappUrl"):
    aviso("whatsappUrl está vacío: el botón de WhatsApp aún no lleva a ningún canal.")
if not cfg.get("amazonTag"):
    err("Falta amazonTag en config.")

ids = set()
for p in datos.get("productos", []):
    n = "producto id=%s (%s)" % (p.get("id"), str(p.get("titulo", ""))[:30])
    for campo in ("id", "titulo", "categoria", "tienda", "url"):
        if p.get(campo) in (None, ""):
            err("%s: falta '%s'" % (n, campo))
    if p.get("id") in ids:
        err("%s: id repetido" % n)
    ids.add(p.get("id"))
    if p.get("categoria") not in cats:
        err("%s: categoría desconocida '%s'" % (n, p.get("categoria")))
    if p.get("tienda") not in tiendas:
        err("%s: tienda desconocida '%s'" % (n, p.get("tienda")))
        continue
    url = p.get("url", "")
    if url == "#":
        (aviso if demo else err)("%s: url es '#'" % n)
    else:
        u = urlparse(url)
        if u.scheme != "https":
            err("%s: la url debe empezar por https://" % n)
        pats = DOMINIOS.get(p["tienda"], [])
        if pats and not any(re.search(r, u.hostname or "") for r in pats):
            err("%s: el dominio '%s' no corresponde a la tienda '%s'" % (n, u.hostname, p["tienda"]))
        if p["tienda"] == "amazon" and "tag=" in url and cfg.get("amazonTag") not in url:
            err("%s: el enlace de Amazon lleva otro tag distinto a amazonTag" % n)
    pr, ant = p.get("precio"), p.get("precioAnterior")
    if pr is not None and not (isinstance(pr, (int, float)) and pr > 0):
        err("%s: precio no válido" % n)
    if ant is not None:
        if pr is None:
            err("%s: hay precioAnterior pero no precio" % n)
        elif ant <= pr:
            err("%s: precioAnterior debe ser mayor que precio" % n)
        elif (1 - pr / ant) > 0.70:
            aviso("%s: descuento superior al 70 %%; comprueba que el precio anterior es real" % n)
    if p.get("tienda") == "amazon" and pr is not None and not cfg.get("amazonPreciosPermitidos"):
        aviso("%s: es de Amazon; la web NO mostrará el precio (la política de Amazon lo restringe)" % n)
    try:
        f = datetime.date.fromisoformat(p.get("actualizado", ""))
        if (hoy - f).days > caduca:
            aviso("%s: actualizado hace %d días; la web lo ocultará (límite %d)" % (n, (hoy - f).days, caduca))
    except ValueError:
        (aviso if demo else err)("%s: 'actualizado' debe tener formato AAAA-MM-DD" % n)
    if p.get("envio") not in ("gratis", "pago", "desconocido", None):
        err("%s: envio debe ser gratis, pago o desconocido" % n)

for pagina in ("aviso-legal.html", "privacidad.html", "cookies.html", "afiliacion.html"):
    f = RAIZ / pagina
    if not f.exists():
        err("Falta la página %s" % pagina)
    elif "[COMPLETAR" in f.read_text(encoding="utf-8"):
        (aviso if demo else err)("%s: aún tiene campos [COMPLETAR]" % pagina)

for a in avisos: print("AVISO :", a)
for e in errores: print("ERROR :", e)
print("\n%d productos revisados, %d errores, %d avisos." % (len(datos.get("productos", [])), len(errores), len(avisos)))
sys.exit(1 if errores else 0)
