#!/usr/bin/env python3
"""Convierte herramientas/productos.csv (hecho en Excel o Google Sheets) en la lista
de productos de data/productos.json, sin tocar la configuración.

Uso:  python3 herramientas/csv_a_json.py
      python3 herramientas/csv_a_json.py --csv otro.csv --salida prueba.json
Guarda el CSV desde Excel como "CSV UTF-8". Acepta ; o , como separador y
precios con coma (4,99)."""
import argparse, csv, json
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
ap = argparse.ArgumentParser()
ap.add_argument("--csv", default=str(RAIZ / "herramientas" / "productos.csv"))
ap.add_argument("--json", default=str(RAIZ / "data" / "productos.json"))
ap.add_argument("--salida", default=None, help="por defecto sobrescribe --json")
a = ap.parse_args()

def numero(t):
    t = (t or "").strip().replace("€", "").replace(" ", "")
    if not t:
        return None
    return float(t.replace(",", "."))

texto = Path(a.csv).read_text(encoding="utf-8-sig")
lineas = texto.splitlines()
sep = ";" if lineas[0].count(";") >= lineas[0].count(",") else ","
filas = list(csv.DictReader(lineas, delimiter=sep))

productos = []
for i, f in enumerate(filas, start=1):
    if not (f.get("titulo") or "").strip():
        continue
    p = {
        "id": int(f["id"]) if (f.get("id") or "").strip() else i,
        "titulo": f["titulo"].strip(),
        "categoria": f["categoria"].strip(),
        "tienda": f["tienda"].strip().lower(),
        "url": f["url"].strip(),
    }
    for campo in ("precio", "precioAnterior"):
        v = numero(f.get(campo))
        if v is not None:
            p[campo] = v
    for campo in ("envio", "img", "actualizado"):
        v = (f.get(campo) or "").strip()
        if v:
            p[campo] = v
    productos.append(p)

datos = json.loads(Path(a.json).read_text(encoding="utf-8"))
datos["productos"] = productos
destino = Path(a.salida or a.json)
destino.write_text(json.dumps(datos, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print("%d productos escritos en %s. Ahora ejecuta: python3 herramientas/validar.py" % (len(productos), destino))
